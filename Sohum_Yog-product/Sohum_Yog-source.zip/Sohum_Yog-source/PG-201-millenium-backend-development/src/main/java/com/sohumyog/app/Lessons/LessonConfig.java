package com.sohumyog.app.Lessons;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.util.Arrays;

@Component
public class LessonConfig implements CommandLineRunner {

    @Autowired
    LessonRepository repository;

    /**
     * Optional:
     * Uncomment this block of code when running the project for this first time to get initial Users into the Database.
     * Re-comment this block of code after running the project for this first time.
     *
     * @param args
     * @throws Exception
     */
    @Override
    public void run(String... args) throws Exception {
        // repository.saveAll(Arrays.asList(
        // new Lessons("Yoga Pilates", "Yoga Pilates, on the other hand, was developed
        // in the early 20th century by Joseph Pilates as a system of exercises to
        // improve physical strength, flexibility, and posture. Pilates focuses on the
        // core muscles, and exercises are typically performed on a mat or with
        // specialised equipment.", 1),
        // new Lessons("Full Body Strech", "Do you love yoga, but you're not in the mood
        // to break a sweat every time you sit at the mat? Maybe you just want to
        // meditate and stretch, to contemplate your day and wish your cares away for a
        // moment. This school focuses on delivering high-quality and free yoga videos
        // to people around the globe.", 1),
        // new Lessons("Gentle Flow", "Gentle Flow is a type of yoga that is designed to
        // be accessible to all levels of fitness and experience. It typically involves
        // slow, flowing movements and gentle stretching, with an emphasis on relaxation
        // and breath awareness. Gentle Flow is a good option for those who want a more
        // relaxing and meditative yoga practice.", 1),
        // new Lessons("Meditation", "Meditation typically involves finding a
        // comfortable seated or lying position, closing the eyes, and focusing on the
        // breath or a specific object or mantra. The goal is to become more aware of
        // one's thoughts and emotions,observe them without judgement, and ultimately
        // find a sense of inner peace and clarity", 2),
        // new Lessons("Pranayama", "Pranayama is a practice in yoga that focuses on
        // breath control and regulation. It is an integral part of traditional yoga and
        // involves various breathing techniques that help harmonize the body and
        // mind.", 3)

        // ));
    }
}
