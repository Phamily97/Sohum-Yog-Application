package com.sohumyog.app.Course;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@RestController
@RequestMapping(path = "/api")
public class CourseController {

    @Autowired
    private final CourseService courseService;

    /**
     * Inject courseService
     * @param courseService
     */
    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    /**
     * GET API: /course
     * @return
     */
    @GetMapping("/course")
    public List<Course> getCourses() {
        return courseService.getAll();
    }

}
