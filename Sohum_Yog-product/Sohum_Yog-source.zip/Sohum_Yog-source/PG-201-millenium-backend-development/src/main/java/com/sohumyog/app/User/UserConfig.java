package com.sohumyog.app.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.util.Arrays;

@Component
public class UserConfig implements CommandLineRunner {

    @Autowired
    UserRepository repository;

    /**
     * Optional:
     * Uncomment this block of code when running the project for this first time to get initial Users into the Database.
     * Re-comment this block of code after running the project for this first time.
     *
     * @param args
     * @throws Exception
     */
    @Override
    public void run(String... args) throws Exception {
        // repository.saveAll(Arrays.asList(
        // new User("van", "password3"),
        // new User("pham", "password4")));

    }
}
