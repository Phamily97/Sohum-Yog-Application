package com.sohumyog.app.Lessons;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Collection;
import java.util.List;

@Service
public class LessonService {

    @Autowired
    private final LessonRepository lessonRepository;

    /**
     * Inject lessonRepository
     * @param lessonRepository
     */
    public LessonService(LessonRepository lessonRepository) {
        this.lessonRepository = lessonRepository;
    }

    /**
     * This methods returns all the lessons in the database
     * @return
     */
    public List<Lessons> getLessons() {
        return lessonRepository.findAll();
    }

    /**
     * This method returns all the Body lessons in the database
     * @return
     */
    public Collection<Lessons> getBodyLessons() {
        return lessonRepository.findAllBodyLessons();
    }

    /**
     * This method returns all the Mind lessons in the database
     * @return
     */
    public Collection<Lessons> getMindLessons() {
        return lessonRepository.findAllMindLessons();
    }

    /**
     * This method returns all the Focus lessons in the database
     * @return
     */
    public Collection<Lessons> getFocusLessons() {
        return lessonRepository.findAllFocusLessons();
    }

}
