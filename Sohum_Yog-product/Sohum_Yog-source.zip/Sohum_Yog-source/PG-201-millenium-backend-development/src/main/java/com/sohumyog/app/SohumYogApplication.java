package com.sohumyog.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SohumYogApplication {

	public static void main(String[] args) {
		SpringApplication.run(SohumYogApplication.class, args);
	}
}
