package com.sohumyog.app.Lessons;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Collection;

@Repository
public interface LessonRepository extends JpaRepository<Lessons, String> {

    /**
     * This method queries the database with enumfkplaceholder = 1 condition to fetch all the Body lessons
     * @return
     */
    @Query(value = "SELECT * FROM sohum_yog_db.lessons u WHERE u.enumfkplaceholder = 1", nativeQuery = true)
    Collection<Lessons> findAllBodyLessons();

    /**
     * This method queries the database with enumfkplaceholder = 2 condition to fetch all the Mind lessons
     * @return
     */
    @Query(value = "SELECT * FROM sohum_yog_db.lessons u WHERE u.enumfkplaceholder = 2", nativeQuery = true)
    Collection<Lessons> findAllMindLessons();

    /**
     * This method queries the database with enumfkplaceholder = 3 condition to fetch all the Focus lessons
     * @return
     */
    @Query(value = "SELECT * FROM sohum_yog_db.lessons u WHERE u.enumfkplaceholder = 3", nativeQuery = true)
    Collection<Lessons> findAllFocusLessons();
}
