package com.sohumyog.app.Lessons;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.Collection;
import java.util.List;

@RestController
@RequestMapping(path = "/api")
public class LessonController {

    @Autowired
    private final LessonService lessonService;

    /**
     * Inject lessonService
     * @param lessonService
     */
    public LessonController(LessonService lessonService) {
        this.lessonService = lessonService;
    }

    /**
     * GET API: /getAllLessons
     * @return
     */
    @GetMapping("/getAllLessons")
    public List<Lessons> getLessons() {
        return lessonService.getLessons();
    }

    /**
     * GET API: /getAllBodyLessons
     * @return
     */
    @GetMapping("/getAllBodyLessons")
    public Collection<Lessons> getAllBodyLessons() {
        return lessonService.getBodyLessons();
    }

    /**
     * GET API: /getAllMindLessons
     * @return
     */
    @GetMapping("/getAllMindLessons")
    public Collection<Lessons> getAllMindLessons() {
        return lessonService.getMindLessons();
    }

    /**
     * GET API: /getAllFocusLessons
     * @return
     */
    @GetMapping("/getAllFocusLessons")
    public Collection<Lessons> getAllFocusLessons() {
        return lessonService.getFocusLessons();
    }
}
