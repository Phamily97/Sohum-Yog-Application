package com.sohumyog.app.Course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.util.Arrays;

@Component
public class CourseConfig implements CommandLineRunner {

    @Autowired
    CourseRepository repository;

    /**
     * Uncomment this block of code when running the project for this first time to get initial Users into the Database.
     * Re-comment this block of code after running the project for this first time.
     *
     * @param args
     * @throws Exception
     */
    @Override
    public void run(String... args) throws Exception {
        // repository.saveAll(Arrays.asList(
        // new Course("Mind"),
        // new Course("Body"),
        // new Course("Focus")
        // ));
    }
}
