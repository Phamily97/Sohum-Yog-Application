package com.sohumyog.app.User;

import jakarta.persistence.*;

@Entity
@Table(name = "users", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class User {

    @Id
    @SequenceGenerator(name = "user_sequence", sequenceName = "user_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
    private Long id;

    private String email;
    private String password;
    private String displayName;
    private String newPassword;

    public User() {
    }

    /**
     *
     * @param id
     * @param email
     * @param password
     */
    public User(Long id, String email, String password) {
        this.id = id;
        this.email = email;
        this.password = password;
    }

    /**
     * Used constructor in the UserConfig class
     * @param email
     * @param password
     */
    public User(String email, String password) {
        this.email = email;
        this.password = password;
        this.displayName = "";
        this.newPassword = "";
    }

    /**
     *
     * @return displayName parameter
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * This method is used to set the default name of the User
     * @param displayName
     *
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     *
     * @return email parameter
     */
    public String getEmail() {
        return email;
    }

    /**
     *  This method is used to set the email parameter of the User
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter for current password
    public String getPassword() {
        return password;
    }

    // Setter for current password
    public void setPassword(String password) {
        this.password = password;
    }

    // Getter for new password
    public String getNewPassword() {
        return newPassword;
    }

    // Setter for new password
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    @Override
    public String toString() {
        return "User{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
