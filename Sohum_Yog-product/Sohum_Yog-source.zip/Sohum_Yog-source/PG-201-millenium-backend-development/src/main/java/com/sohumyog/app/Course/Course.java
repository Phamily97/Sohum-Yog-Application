package com.sohumyog.app.Course;

import com.sohumyog.app.Lessons.Lessons;
import jakarta.persistence.*;

import java.util.Set;

@Entity
@Table(name = "course")
public class Course {

    @Id
    @SequenceGenerator(name = "course_sequence", sequenceName = "course_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "course_sequence")
    private Long id;

    private String name;

    @OneToMany
    private Set<Lessons> items;

    public Course() {
    }

    /**
     *
     * @param id
     * @param name
     */
    public Course(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * This is the constructor used in the CourseConfig file
     * @param name
     */
    public Course(String name) {
        this.name = name;
    }

    /**
     * This is a default get method for the name paramter
     * @return
     */
    public String getCourseName() {
        return name;
    }

    /**
     * This is a default set method for the name paramter
     * @param name
     */
    public void setCourseName(String name) {
        this.name = name;
    }

    /**
     * toString method for console testing
     * @return
     */
    @Override
    public String toString() {
        return "Course{" +
                "courseName='" + name + '\'' +
                '}';
    }
}
