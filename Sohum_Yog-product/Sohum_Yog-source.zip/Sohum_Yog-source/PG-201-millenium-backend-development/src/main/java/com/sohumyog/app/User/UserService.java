package com.sohumyog.app.User;

import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;

    private String savedLogin = "";

    // @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * This method returns a List of all the users in the database
     * @return
     */
    public List<User> getUser() {

        System.out.println("Received GET request for all users...");
        return userRepository.findAll();
    }

    /**
     * This method is used to register a User
     * @param user
     * @return
     */
    public String signUp(User user) {

        Optional<User> existingUser = userRepository.findByEmail(user.getEmail());

        if (existingUser.isPresent()) {
            return "This email already exists, please use a different email";
        } else {
            userRepository.save(user);
            return "This user is registered successfully";
        }

    }

    /**
     * This is a method to display the name of the logged in user to the dashboard
     * @return
     */
    public String getLoginEmail() {
        if (!"".equals(savedLogin)) {
            return "Welcome back, " + savedLogin;
        } else {
            return "Unknown.";
        }
    }

    /**
     * This is a method to change the displayName of the User
     * @param displayName
     */
    public void changeDisplayName(String displayName) {

        // Formatting display name
        String[] name1 = displayName.split(":");
        String[] name2 = name1[1].split("}");
        String name3 = name2[0].trim();
        name3 = name3.substring(1, name3.length() - 1);

        System.out.println("Your new display name is: " + name3);
        System.out.println("You have finished updating your display name.");

        userRepository.createName(name3, savedLogin);
    }

    /**
     * This is a method to sign-in
     * @param user
     * @return
     */
    public String signIn(User user) {
        Optional<User> loginUser = userRepository.findByEmail(user.getEmail());
        if (loginUser.isEmpty() || !loginUser.get().getPassword().equals(user.getPassword())) {
            return "false";
        } else {
            savedLogin = loginUser.get().getEmail();
            return "true";
        }
    }

    /**
     * This is a method to update the password of the User
     * @param user
     */
    public void changePassword(User user) {

        Optional<User> loginUser = userRepository.findByEmail(user.getEmail());
        System.out.println("Updating password for user: " + user.getEmail());

        // Checking if the given password is equal to the password stored in the
        // database
        if (loginUser.get().getPassword().equals(user.getPassword())) {

            // Only runs if the statement is true
            System.out.println("Updating password...");
            user.setPassword(user.getNewPassword());

            System.out.println("Update complete. The new password for this user is: " + user.getPassword());
            System.out.println("You have finished updating your password.");
            userRepository.changePassword(user.getPassword(), savedLogin);
        } else {
            System.out.println("Error: failed to update your password.");
        }
    }
}
