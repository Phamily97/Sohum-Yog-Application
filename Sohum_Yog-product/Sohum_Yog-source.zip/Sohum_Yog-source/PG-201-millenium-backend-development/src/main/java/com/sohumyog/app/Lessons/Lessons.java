package com.sohumyog.app.Lessons;

import jakarta.persistence.*;

@Entity
@Table(name = "lessons")
public class Lessons {

    @Id
    @SequenceGenerator(name = "lessons_sequence", sequenceName = "lessons_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "lessons_sequence")
    private Long id;

    private String name;

    @Column(name = "description", length = 1000)
    private String description;

    private int enumFKplaceholder;

    public Lessons() {
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param enumFKplaceholder
     */
    public Lessons(Long id, String name, String description, int enumFKplaceholder) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.enumFKplaceholder = enumFKplaceholder;
    }

    /**
     * This is the constructor used in the LessonConfig file
     * @param name
     * @param description
     * @param enumFKplaceholder
     */
    public Lessons(String name, String description, int enumFKplaceholder) {
        this.name = name;
        this.description = description;
        this.enumFKplaceholder = enumFKplaceholder;
    }

    /**
     * This is a default get method for name parameter
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * This is a default set method for name parameter
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * This is a default get method for description parameter
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     * This is a default set method for the description parameter
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * This is a default get method for the enumFKplaceholder parameter
     * @return
     */
    public int getEnumFKplaceholder() {
        return enumFKplaceholder;
    }

    /**
     * This is a default get method for the enumFKplaceholder paramter
     * @param enumFKplaceholder
     */
    public void setEnumFKplaceholder(int enumFKplaceholder) {
        this.enumFKplaceholder = enumFKplaceholder;
    }

    /**
     * This is a toString method for the backend console for testing
     * @return
     */
    @Override
    public String toString() {
        return "Course{" +
                "lessonName='" + name + '\'' +
                ", description='" + description + '\'' +
                ", FKenum='" + enumFKplaceholder + '\'' +
                '}';
    }
}
