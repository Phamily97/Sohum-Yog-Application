package com.sohumyog.app.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping(path = "/api")
public class UserController {

    @Autowired
    private final UserService userService;

    /**
     * userService injection
     * @param userService
     */
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * POST API: /sign-up
     * @param user
     * @return
     */
    @PostMapping("/sign-up")
    public String signUp(@RequestBody User user) {
        return userService.signUp(user);
    }

    /**
     * POST API: /sign-in
     * @param user
     * @return
     */
    @PostMapping("/sign-in")
    public String signIn(@RequestBody User user) {
        return userService.signIn(user);
    }

    /**
     * POST API: /changeName
     * @param displayName
     */
    @PostMapping("/changeName")
    public void changeDisplayName(@RequestBody String displayName) {
        userService.changeDisplayName(displayName);
    }

    /**
     * POST API: /changePassword
     * @param user
     */
    @PostMapping("/changePassword")
    public void changePassword(@RequestBody User user) {
        userService.changePassword(user);
    }

    /**
     * GET API: /dashboard
     * @return
     */
    @GetMapping("/dashboard")
    // expand to include the different yoga course available
    public String savedUser() {
        return userService.getLoginEmail();
    }

}
