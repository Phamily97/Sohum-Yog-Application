package com.sohumyog.app.User;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, String> {

    Optional<User> findByEmail(String email);

    /**
     * This is a method used to change the name of the User that is currently logged in
     * @param displayName
     * @param savedLogin
     */
    @Transactional
    @Modifying
    @Query(value = "update sohum_yog_db.users c set c.display_name =?1 where c.email =?2", nativeQuery = true)
    void createName(String displayName, String savedLogin);

    /**
     * This is a method used to change the password of the User that is currently logged in
     * @param newPassword
     * @param savedLogin
     */
    @Transactional
    @Modifying
    @Query(value = "update sohum_yog_db.users c set c.password =?1 where c.email =?2", nativeQuery = true)
    void changePassword(String newPassword, String savedLogin);

}
