package com.sohumyog.app.Course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CourseService {

    @Autowired
    private final CourseRepository courseRepository;

    /**
     * Inject courseRepository
     * @param courseRepository
     */
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    /**
     * This method returns the names of all the courses in the database
     * @return
     */
    public List<Course> getAll() {
        return courseRepository.findAll();
    }
}
