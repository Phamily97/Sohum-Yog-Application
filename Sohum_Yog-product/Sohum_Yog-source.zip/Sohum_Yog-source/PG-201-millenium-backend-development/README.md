# PG-201-SohumYog-Backend

## Steps:
1. Download and install JDK19 or later
2. Download and install MySQL workbench

## Configure:
1. In MySQL workbench, create a schema called sohum_yog_db
2. In applications.properties file, change the username and password to match your machine
