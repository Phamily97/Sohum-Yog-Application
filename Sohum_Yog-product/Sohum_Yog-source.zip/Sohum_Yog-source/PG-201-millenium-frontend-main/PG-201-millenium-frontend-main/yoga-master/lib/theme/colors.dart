import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFFFFF3ED);
const Color iconColor = Color(0xFFBE6A25);
const Color secondaryColor = Color(0xffa7a666);
