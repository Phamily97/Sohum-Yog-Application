import 'package:flutter/material.dart';

const kAppName = 'Sohum Yog';

const scaffoldBackgroundColor = Color.fromRGBO(255, 241, 233, 1);
const buttonColor = Color.fromRGBO(167, 166, 109, 1);
