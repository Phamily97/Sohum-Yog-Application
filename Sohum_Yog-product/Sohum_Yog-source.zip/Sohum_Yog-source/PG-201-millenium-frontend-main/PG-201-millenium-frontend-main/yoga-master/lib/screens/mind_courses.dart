import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:yoga/screens/home.dart';
import 'package:yoga/screens/lessons/lesson4.dart';
import 'package:yoga/theme/colors.dart';

// This class displays a screen that shows mind courses and recommended lessons
class MindCourses extends StatelessWidget {
  const MindCourses({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryColor,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 375,
              height: 812,
              child: Material(
                color: const Color(0xfffff3ed),
                child: Padding(
                  padding: const EdgeInsets.only(
                    bottom: 21,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: 375,
                        height: 44,
                        padding: const EdgeInsets.only(
                          left: 20,
                          right: 15,
                          top: 14,
                          bottom: 12,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: const [
                            SizedBox(width: 219.61),
                            SizedBox(
                              width: 67,
                              height: 11.50,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 343,
                        child: Text(
                          "Mind Exercises",
                          style: TextStyle(
                            color: Color(0xff2b2b2b),
                            fontSize: 34,
                            fontFamily: "PlayfairDisplay",
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.50,
                          ),
                        ),
                      ),
                      const SizedBox(height: 24.25),
                      SizedBox(
                        width: 343,
                        child: Material(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                const SizedBox(
                                  width: 279,
                                  child: Text(
                                    "Search",
                                    style: TextStyle(
                                      color: Color(0xb22b2b2b),
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Image.asset('assets/icons/search.png'),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24.25),
                      SizedBox(
                        width: 330,
                        height: 73,
                        child: Stack(
                          children: [
                            const Positioned.fill(
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: SizedBox(
                                  child: Text(
                                    "Browse Category",
                                    style: TextStyle(
                                      color: Color(0xff2b2b2b),
                                      fontSize: 16,
                                      fontFamily: "PlayfairDisplay",
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned.fill(
                              child: Align(
                                alignment: Alignment.bottomLeft,
                                child: SizedBox(
                                  width: 96,
                                  height: 40,
                                  child: Material(
                                    color: const Color(0xffa7a666),
                                    borderRadius: BorderRadius.circular(10),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 8,
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: const [
                                          Text(
                                            "5-10 mins",
                                            style: TextStyle(
                                              color: Color(0xfffcfcff),
                                              fontSize: 14,
                                              fontFamily: "Roboto",
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned.fill(
                              child: Align(
                                alignment: Alignment.bottomCenter,
                                child: SizedBox(
                                  height: 40,
                                  child: Material(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 8,
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: const [
                                          Text(
                                            "15-20 mins",
                                            style: TextStyle(
                                              color: Color(0xb22b2b2b),
                                              fontSize: 14,
                                              fontFamily: "Roboto",
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned.fill(
                              child: Align(
                                alignment: Alignment.bottomRight,
                                child: SizedBox(
                                  width: 96,
                                  height: 40,
                                  child: Material(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 8,
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: const [
                                          Text(
                                            "25+ mins",
                                            style: TextStyle(
                                              color: Color(0xb22b2b2b),
                                              fontSize: 14,
                                              fontFamily: "Roboto",
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24.25),
                      // COURSES
                      const SizedBox(
                        width: 330,
                        child: Text(
                          "Recommended Courses",
                          style: TextStyle(
                            color: Color(0xff2b2b2b),
                            fontSize: 16,
                            fontFamily: "PlayfairDisplay",
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      const SizedBox(height: 24.25),
                      SizedBox(
                        width: 343,
                        child: Material(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => Lesson4(),
                                ),
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(15),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        width: 75,
                                        height: 75,
                                        child: Material(
                                          color: const Color(0xfffbe6da),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                              left: 11,
                                              right: 10,
                                              top: 4,
                                              bottom: 3,
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  width: 53.57,
                                                  height: 68,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8),
                                                  ),
                                                  child: Image.asset(
                                                      'assets/images/meditation.png'),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 20),
                                      SizedBox(
                                        width: 200,
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const SizedBox(
                                              width: 200,
                                              child: Text(
                                                "Meditation",
                                                style: TextStyle(
                                                  color: Color(0xff161719),
                                                  fontSize: 14,
                                                  fontFamily: "PlayfairDisplay",
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 6),
                                            const SizedBox(
                                              width: 200,
                                              child: Text(
                                                "5 lessons",
                                                style: TextStyle(
                                                  color: Color(0xb22b2b2b),
                                                  fontSize: 12,
                                                  fontFamily: "Roboto",
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 6),
                                            SizedBox(
                                              height: 15,
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      Container(
                                                        width: 13,
                                                        height: 13,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8),
                                                        ),
                                                        child: Image.asset(
                                                            'assets/icons/star.png'),
                                                      ),
                                                      const SizedBox(width: 5),
                                                      const Text(
                                                        "4.5",
                                                        style: TextStyle(
                                                          color:
                                                              Color(0xb22b2b2b),
                                                          fontSize: 10,
                                                          fontFamily: "Roboto",
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  const SizedBox(width: 5),
                                                  const SizedBox(
                                                    width: 3,
                                                    height: 3,
                                                    child: Material(
                                                      color: Color(0xffaaaaaa),
                                                      shape: CircleBorder(),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 5),
                                                  const Text(
                                                    "By Sarah William",
                                                    style: TextStyle(
                                                      color: Color(0xffaaaaaa),
                                                      fontSize: 10,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 5),
                                                  const SizedBox(
                                                    width: 3,
                                                    height: 3,
                                                    child: Material(
                                                      color: Color(0xffaaaaaa),
                                                      shape: CircleBorder(),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 5),
                                                  const Text(
                                                    "All Level",
                                                    style: TextStyle(
                                                      color: Color(0xffaaaaaa),
                                                      fontSize: 10,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: false,
        showUnselectedLabels: false,
        selectedItemColor: iconColor,
        type: BottomNavigationBarType.fixed,
        backgroundColor: primaryColor,
        unselectedItemColor: const Color(0xffAAAAAA),
        elevation: 0,
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => HomeScreen()),
            );
          } else {
            // Handle other options
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.chart),
            label: 'Chart',
          ),
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.search),
            label: 'search',
          ),
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.profile),
            label: 'profile',
          ),
        ],
      ),
    );
  }
}
