import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:yoga/screens/auth/signin_page.dart';
import 'package:yoga/screens/body_courses.dart';
import 'package:yoga/screens/focus_courses.dart';
import 'package:yoga/screens/mind_courses.dart';
import 'package:yoga/theme/colors.dart';

// This class displays the home screen
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double _value = 0.0;
  List<Map> practicesList = [
    {
      'title': 'Mind',
      'subtitle': 'Let’s train it',
      'image': 'assets/mind.png',
    },
    {
      'title': 'Body',
      'subtitle': 'Refrain stress',
      'image': 'assets/mind.png',
    },
    {
      'title': 'Focus',
      'subtitle': 'Focus on work',
      'image': 'assets/mind.png',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryColor,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 50),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Expanded(
                  flex: 4,
                  child: Padding(
                    padding: EdgeInsets.only(top: 30),
                    child: Text(
                      "Namaste,\nKate",
                      style: TextStyle(
                        color: Color(0xff2b2b2b),
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.50,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  flex: 6,
                  child: Image.asset(
                    'assets/girl.png',
                    height: 220,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
            const Text(
              "Day 5",
              style: TextStyle(
                color: Color(0xff2b2b2b),
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            const Text(
              "Essentials . Level 1",
              style: TextStyle(
                color: Color(0xff2b2b2b),
                fontSize: 14,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: CupertinoSlider(
                min: 0.0,
                max: 100.0,
                value: _value,
                activeColor: secondaryColor,
                thumbColor: Colors.white,
                onChanged: (value) {
                  setState(() {
                    _value = value;
                  });
                },
              ),
            ),
            const SizedBox(height: 15),
            Container(
              height: 173,
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Image.asset(
                'assets/chart.png',
                fit: BoxFit.fill,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Latest Practices",
              style: TextStyle(
                color: Color(0xff2b2b2b),
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: const [
                PracticeWidget(
                  title: 'Mind',
                  subtitle: 'Let’s train it',
                  image: 'assets/mind.png',
                ),
                SizedBox(width: 10),
                PracticeWidget(
                  title: 'Body',
                  subtitle: 'Refrain stress',
                  image: 'assets/relax.png',
                ),
                SizedBox(width: 10),
                PracticeWidget(
                  title: 'Focus',
                  subtitle: 'Focus on work',
                  image: 'assets/focus.png',
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: false,
        showUnselectedLabels: false,
        selectedItemColor: iconColor,
        type: BottomNavigationBarType.fixed,
        backgroundColor: primaryColor,
        unselectedItemColor: const Color(0xffAAAAAA),
        elevation: 0,
        onTap: (index) {
          if (index == 1) {
            Navigator.pushAndRemoveUntil(context,
                MaterialPageRoute(builder: (_) => SigninPage()), (_) => false);
          } else {
            // Handle other options
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.logout),
            label: 'Chart',
          ),
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.search),
            label: 'search',
          ),
          BottomNavigationBarItem(
            icon: Icon(IconlyBold.profile),
            label: 'profile',
          ),
        ],
      ),
    );
  }
}

class PracticeWidget extends StatelessWidget {
  final String title;
  final String subtitle;
  final String image;

  const PracticeWidget({
    super.key,
    required this.title,
    required this.subtitle,
    required this.image,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          if (title == 'Mind') {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const MindCourses(),
              ),
            );
          } else if (title == 'Body') {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const BodyCourses(),
              ),
            );
          } else if (title == 'Focus') {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const FocusCourses(),
              ),
            );
          }
        },
        child: Container(
          height: 119,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            boxShadow: const [
              BoxShadow(
                color: Color(0x07241f1d),
                blurRadius: 40,
                offset: Offset(0, 20),
              ),
            ],
            color: secondaryColor,
          ),
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.topRight,
                child: Image.asset(
                  image,
                  height: 32,
                  width: 32,
                  color: Colors.white,
                ),
              ),
              const Spacer(),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
