import 'package:yoga/screens/auth/signup_page.dart';
import 'package:yoga/widgets/app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:yoga/screens/home.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';

// This class displays the sign in page
class SigninPage extends StatefulWidget {
  const SigninPage({Key? key}) : super(key: key);

  @override
  State<SigninPage> createState() => _SigninPageState();
}

class _SigninPageState extends State<SigninPage> {
  final _formKey = GlobalKey<FormState>();

  final _emailTec = TextEditingController();
  final _passTec = TextEditingController();

  bool _showPass = false;

  final apiURL = "localhost:8080";
  final path = "/api/sign-in";
  late var url;

  _signIn() {
    if (_formKey.currentState!.validate()) {
      debugPrint('Email: ${_emailTec.text}');
      debugPrint('Password: ${_passTec.text}');
      url = Uri.http(apiURL, path);
      save();
    }
  }

  Future<void> save() async {
    var hashPassword = md5.convert(utf8.encode(_passTec.text)).toString();
    var res = await http.post(url,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: jsonEncode({"email": _emailTec.text, "password": hashPassword}));
    print(res.body);
    if (res.body != null && res.body == "true") {
      debugPrint('Redirecting you to the Home Screen');
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const HomeScreen(),
          ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Hero(
                        tag: 'iconTag',
                        child: Image.asset(
                          'assets/images/logo.png',
                          height: MediaQuery.of(context).size.width * 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),

                    const Text(
                      'Sign in',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 30,
                      ),
                    ),
                    const SizedBox(height: 50),

                    // Email
                    TextFormField(
                      controller: _emailTec,
                      validator: (value) =>
                          value!.isEmpty ? 'This field is required' : null,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        labelText: 'Email',
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Password
                    TextFormField(
                      controller: _passTec,
                      obscureText: !_showPass,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (value) =>
                          value!.isEmpty ? 'This field is required' : null,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        labelText: 'Password',
                        suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              _showPass = !_showPass;
                            });
                          },
                          icon: Icon(
                            _showPass
                                ? CupertinoIcons.eye
                                : CupertinoIcons.eye_slash,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text('Forgot Password?'),
                    const SizedBox(height: 20),

                    // Sign in button
                    AppButton(text: 'Sign In', onPressed: _signIn),
                    const SizedBox(height: 20),

                    // Register
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "Don't have an account?",
                          style: TextStyle(
                            color: Color.fromARGB(255, 53, 53, 53),
                          ),
                        ),
                        const SizedBox(width: 5),
                        InkWell(
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const SignupPage(),
                              ),
                            );
                          },
                          child: const Text(
                            'Sign up',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
