import 'package:flutter/material.dart';
import 'package:yoga/screens/auth/signin_page.dart';
import 'package:yoga/screens/auth/signup_page.dart';

import '../app_config.dart';
import '../widgets/app_button.dart';

// This class displays the entry screen to select to sign in or sign up for the application
class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    const SizedBox(height: 40),
                    Hero(
                      tag: 'iconTag',
                      child: Image.asset(
                        'assets/images/logo.png',
                        height: MediaQuery.of(context).size.width * 0.5,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      kAppName,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    // Sign in button
                    AppButton(
                      text: 'Sign In',
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SigninPage(),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 30),

                    // Sign up button
                    AppButton(
                      text: 'Sign Up',
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SignupPage(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
