// ignore_for_file: no_leading_underscores_for_local_identifiers

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:yoga/screens/mind_courses.dart';

// This class displays the Meditation lesson screen
class Lesson4 extends StatelessWidget {
  const Lesson4({super.key});

  @override
  Widget build(BuildContext context) {
    void _onVolume() {}

    void _onBackward() {}

    void _onForward() {}

    void _onPlayPause() {}

    void _onStart() {}

    return Scaffold(
      backgroundColor: const Color.fromRGBO(82, 71, 66, 1),
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              child: Container(
                color: const Color.fromRGBO(82, 71, 66, 1),
                height:
                    MediaQuery.of(context).size.height * 0.6 + kToolbarHeight,
              ),
            ),
            Positioned(
              child: Container(
                color: const Color.fromRGBO(253, 244, 237, 1),
                height:
                    MediaQuery.of(context).size.height * 0.269 + kToolbarHeight,
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: kToolbarHeight),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              height: MediaQuery.of(context).size.height * 0.55,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/lesson4.png'),
                ),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => MindCourses()),
                          );
                        },
                        icon: const Icon(CupertinoIcons.chevron_back),
                        iconSize: 30,
                      ),
                      IconButton(
                        onPressed: _onVolume,
                        icon: Image.asset('assets/icons/volume.png'),
                        iconSize: 25,
                      ),
                    ],
                  ),
                  const Spacer(),
                  const Text(
                    '00:15',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        IconButton(
                          onPressed: _onBackward,
                          color: Colors.white,
                          icon: const Icon(CupertinoIcons.backward),
                          iconSize: 32,
                        ),
                        IconButton(
                          onPressed: _onPlayPause,
                          color: Colors.white,
                          iconSize: 32,
                          icon: const Icon(CupertinoIcons.play),
                        ),
                        IconButton(
                          onPressed: _onForward,
                          iconSize: 32,
                          color: Colors.white,
                          icon: const Icon(CupertinoIcons.forward_end_alt),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
            Positioned.fill(
              top: MediaQuery.of(context).size.height * 0.62,
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                ),
                height: MediaQuery.of(context).size.height * 0.62,
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text(
                      'Meditation',
                      style: GoogleFonts.playfairDisplay(
                        fontWeight: FontWeight.bold,
                        fontSize: 24.0,
                        color: const Color(0xFF2B2B2B),
                      ),
                    ),
                    Text(
                      '15 min',
                      style: GoogleFonts.roboto(
                        fontSize: 14.0,
                        color: const Color(0xFF2B2B2B),
                      ),
                    ),
                    Text(
                      'Meditation typically involves finding a comfortable seated or lying position, closing the eyes, and focusing on the breath or a specific object or mantra. The goal is to become more aware of one\'s thoughts and emotions, observe them without judgement, and ultimately find a sense of inner peace and clarity.',
                      style: GoogleFonts.roboto(
                        fontSize: 14.0,
                        color: const Color(0xFF2B2B2B).withOpacity(0.7),
                        wordSpacing: 1.5,
                      ),
                      textAlign: TextAlign.justify,
                    ),
                    InkWell(
                      onTap: _onStart,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        decoration: BoxDecoration(
                          color: const Color(0xFFA7A666),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            'Start',
                            style: GoogleFonts.roboto(
                              fontSize: 18.0,
                              color: const Color(0xFFF6EFEB),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
