import 'package:yoga/screens/auth/signin_page.dart';
import 'package:yoga/widgets/app_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import '../home.dart';

//This class displays the sign up page
class SignupPage extends StatefulWidget {
  const SignupPage({Key? key}) : super(key: key);

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _formKey = GlobalKey<FormState>();

  final _fullNameTec = TextEditingController();
  final _emailTec = TextEditingController();

  final _passTec = TextEditingController();
  final _confirmPassTec = TextEditingController();

  final apiURL = "localhost:8080";
  final path = "/api/sign-up";
  late var url;

  bool _showPass = false;

  _signUp() {
    if (_formKey.currentState!.validate()) {
      debugPrint('Full Name: ${_fullNameTec.text}');
      debugPrint('Email: ${_emailTec.text}');
      debugPrint('Password: ${_passTec.text}');
      url = Uri.http(apiURL, path);
      save();
    }
  }

  Future<void> save() async {
    var hashPassword = md5.convert(utf8.encode(_passTec.text)).toString();
    var res = await http.post(url,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: jsonEncode({
          "displayName": _fullNameTec.text,
          "email": _emailTec.text,
          "password": hashPassword
        }));
    print(res.body);
    if (res.body != null) {
      debugPrint('Redirecting you to the Home Screen');
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const HomeScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Form(
              autovalidateMode: AutovalidateMode.onUserInteraction,
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Hero(
                          tag: 'iconTag',
                          child: Image.asset(
                            'assets/images/logo.png',
                            height: MediaQuery.of(context).size.width * 0.5,
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),

                      const Text(
                        'Sign up',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 30,
                        ),
                      ),
                      const SizedBox(height: 40),

                      // Full Name
                      TextFormField(
                        controller: _fullNameTec,
                        validator: (value) =>
                            value!.isEmpty ? 'This field is required' : null,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(color: Colors.black),
                          ),
                          labelText: 'Full Name',
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Email
                      TextFormField(
                        controller: _emailTec,
                        validator: (value) =>
                            value!.isEmpty ? 'This field is required' : null,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(color: Colors.black),
                          ),
                          labelText: 'Email',
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Password
                      TextFormField(
                        controller: _passTec,
                        validator: (value) =>
                            value!.isEmpty ? 'This field is required' : null,
                        obscureText: !_showPass,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(color: Colors.black),
                          ),
                          labelText: 'Password',
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                _showPass = !_showPass;
                              });
                            },
                            icon: Icon(
                              _showPass
                                  ? CupertinoIcons.eye
                                  : CupertinoIcons.eye_slash,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Password
                      TextFormField(
                        controller: _confirmPassTec,
                        obscureText: !_showPass,
                        validator: (value) => value!.isEmpty
                            ? 'This field is required'
                            : value != _passTec.text
                                ? 'Password does not match'
                                : null,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(color: Colors.black),
                          ),
                          labelText: 'Confirm Password',
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                _showPass = !_showPass;
                              });
                            },
                            icon: Icon(
                              _showPass
                                  ? CupertinoIcons.eye
                                  : CupertinoIcons.eye_slash,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Sign in button
                      AppButton(text: 'Sign Up', onPressed: _signUp),

                      const SizedBox(height: 20),

                      // Register
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            "Already an account?",
                            style: TextStyle(
                              color: Color.fromARGB(255, 53, 53, 53),
                            ),
                          ),
                          const SizedBox(width: 5),
                          InkWell(
                            onTap: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const SigninPage(),
                                ),
                              );
                            },
                            child: const Text(
                              'Sign in',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )
                        ],
                      ),
                    ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
