package com.example.yoga

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
