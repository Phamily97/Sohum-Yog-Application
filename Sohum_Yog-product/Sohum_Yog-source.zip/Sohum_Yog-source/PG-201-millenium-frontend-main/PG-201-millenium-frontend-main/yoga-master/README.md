# PG-201-SohumYog-Frontend

## How to run flutter in vs code:
1. Install flutter sdk for MacOS
2. Install flutter extension in vs code
3. Install dart extension in vs code

## Download android studio to import emulator and follow the videos
1. https://youtu.be/0SRvmcsRu2w
2. https://youtu.be/OlswAb-CV8k